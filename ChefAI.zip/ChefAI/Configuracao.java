import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Responsável por ler o arquivo config.properties.
 * Blinda o código contra espaços invisíveis usando .trim()
 */
public class Configuracao {
    
    private static Properties props = new Properties();

    public static void carregar() {
        try {
            FileInputStream arquivo = new FileInputStream("config.properties");
            props.load(arquivo);
            arquivo.close();
        } catch (IOException e) {
            System.out.println("ERRO CRÍTICO: O arquivo config.properties não foi encontrado na pasta do projeto!");
        }
    }

    public static String getApiKey() {
        if (props.isEmpty()) carregar();
        String chave = props.getProperty("api.key");
        // O .trim() remove espaços em branco antes ou depois da chave
        return (chave != null) ? chave.trim() : null;
    }
    
    public static String getApiUrl() {
        if (props.isEmpty()) carregar();
        String url = props.getProperty("api.url");
        // O .trim() remove espaços que quebram o link
        return (url != null) ? url.trim() : null;
    }
}