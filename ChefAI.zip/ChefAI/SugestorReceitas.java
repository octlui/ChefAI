import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * CLASSE ABSTRATA (Mãe).
 */
public abstract class SugestorReceitas {

    protected LLMClient llmClient;

    public SugestorReceitas() {
        this.llmClient = new LLMClient();
    }

    /**
     * MÉTODO TEMPLATE: A receita do bolo de como sugerir.
     * Ninguém mexe na lógica, apenas nos detalhes.
     */
    public final List<Receita> gerarSugestoes(Usuario usuario) {
        System.out.println("1. Entendendo o perfil do usuário...");
        // Chama o método abstrato que o filho vai implementar
        String prompt = construirPromptCompleto(usuario);
        
        System.out.println("2. Consultando o ChefAI (Gemini 2.5)...");
        String jsonResposta = llmClient.enviarPrompt(prompt);
        
        // Se a API devolver erro (ex: cota), retornamos lista vazia para não quebrar
        if (jsonResposta.contains("ERRO")) {
            System.out.println("Falha na comunicação: " + jsonResposta);
            return new ArrayList<>();
        }
        
        System.out.println("3. Traduzindo resposta...");
        String textoPuro = extrairTextoDoJson(jsonResposta);
        
        return processarTextoEmReceitas(textoPuro);
    }

    // --- O QUE CADA FILHO PRECISA DEFINIR ---
    protected abstract String getInstrucaoEspecial();

    protected String construirPromptCompleto(Usuario usuario) {
        StringBuilder sb = new StringBuilder();
        sb.append("Atue como um chef de cozinha experiente. ");
        sb.append("O usuário tem estes ingredientes disponíveis: ");
        
        // Listamos os ingredientes da despensa
        for (Ingrediente i : usuario.getDespensa()) {
            sb.append(i.getNome()).append(", ");
        }
        
        // Adicionamos as restrições (se houver)
        if (!usuario.getRestricoes().isEmpty()) {
            sb.append(". ATENÇÃO às restrições alimentares: ").append(usuario.getRestricoes());
        }
        
        // Aqui entra a regra do filho (ex: "Seja rápido", "Seja saudável")
        sb.append(". ").append(getInstrucaoEspecial());
        
        // Formatação Rígida para o Java conseguir ler depois
        sb.append(" IMPORTANTE: Retorne ESTRITAMENTE 3 sugestões no seguinte formato, separado por pipes '|': ");
        sb.append("Nome da Receita|Tempo em minutos (só números)|Ingredientes usados|Resumo do preparo.");
        sb.append(" Use uma linha por receita. Não use Markdown (**negrito**). Não faça introduções.");
        
        return sb.toString();
    }

    // Pega o JSON do Google e tira só a mensagem de texto
    private String extrairTextoDoJson(String json) {
        // Procura pelo campo "text": "..." dentro da resposta
        Pattern pattern = Pattern.compile("\"text\":\\s*\"(.*?)\"");
        Matcher matcher = pattern.matcher(json);
        StringBuilder textoCompleto = new StringBuilder();
        
        while (matcher.find()) {
            // Limpa caracteres de escape (\n vira enter, \" vira aspas)
            String trecho = matcher.group(1).replace("\\n", "\n").replace("\\\"", "\"");
            textoCompleto.append(trecho);
        }
        return textoCompleto.toString();
    }

    // Transforma o texto (String) em objetos Java (Receita)
    private List<Receita> processarTextoEmReceitas(String texto) {
        List<Receita> lista = new ArrayList<>();
        String[] linhas = texto.split("\n");
        
        for (String linha : linhas) {
            // Ignora linhas vazias
            if (linha.trim().isEmpty()) continue;
            
            // Quebra a linha onde tem o caractere PIPE (|)
            String[] partes = linha.split("\\|");
            
            // Se tiver as 4 partes (Nome, Tempo, Ingredientes, Preparo)
            if (partes.length >= 4) {
                try {
                    String nome = partes[0].trim();
                    // Pega só os números do tempo
                    String tempoStr = partes[1].replaceAll("[^0-9]", "");
                    int tempo = tempoStr.isEmpty() ? 0 : Integer.parseInt(tempoStr);
                    String ingredientesTexto = partes[2].trim();
                    String preparo = partes[3].trim();
                    
                    Receita r = new Receita(nome, tempo, preparo);
                    
                    // Adiciona os ingredientes na receita
                    for (String ing : ingredientesTexto.split(",")) {
                        r.adicionarIngrediente(new Ingrediente(ing.trim(), "a gosto"));
                    }
                    
                    lista.add(r);
                } catch (Exception e) {
                    System.out.println("Não consegui ler a linha: " + linha);
                }
            }
        }
        return lista;
    }
}