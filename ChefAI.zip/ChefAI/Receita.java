import java.util.ArrayList;
import java.util.List;

public class Receita {
    private String nome;
    private int tempoPreparoMinutos;
    private String modoPreparo;
    private List<Ingrediente> ingredientes;

    public Receita(String nome, int tempoPreparoMinutos, String modoPreparo) {
        this.nome = nome;
        this.tempoPreparoMinutos = tempoPreparoMinutos;
        this.modoPreparo = modoPreparo;
        this.ingredientes = new ArrayList<>();
    }

    public void adicionarIngrediente(Ingrediente ing) {
        this.ingredientes.add(ing);
    }

    /**
     * Agora este método recebe a despensa para comparar!
     */
    public String getDetalhes(List<Ingrediente> despensaUsuario) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ").append(nome).append(" (").append(tempoPreparoMinutos).append(" min) ===\n");
        sb.append("Ingredientes:\n");
        
        for (Ingrediente ingReceita : ingredientes) {
            boolean temNaDespensa = false;
            
            // Verifica se este ingrediente da receita existe na despensa do usuário
            for (Ingrediente ingDespensa : despensaUsuario) {
                // Compara ignorando maiúsculas/minúsculas e verifica se um contém o outro
                // Ex: "Farinha" bate com "Farinha de Trigo"
                String nomeReceita = ingReceita.getNome().toLowerCase();
                String nomeDespensa = ingDespensa.getNome().toLowerCase();
                
                if (nomeReceita.contains(nomeDespensa) || nomeDespensa.contains(nomeReceita)) {
                    temNaDespensa = true;
                    break;
                }
            }
            
            if (temNaDespensa) {
                sb.append(" [OK] ").append(ingReceita.getNome()).append(" (NA DESPENSA)\n");
            } else {
                sb.append(" [  ] ").append(ingReceita.getNome()).append("\n"); // Vazio = falta comprar
            }
        }
        
        sb.append("Preparo: ").append(modoPreparo).append("\n");
        return sb.toString();
    }
}