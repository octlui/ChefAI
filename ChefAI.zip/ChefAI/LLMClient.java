import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;

public class LLMClient {

    private final HttpClient client;

    public LLMClient() {
        this.client = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(30))
                .build();
    }

    public String enviarPrompt(String prompt) {
        try {
            // 1. Carregar configurações
            String apiKey = Configuracao.getApiKey();
            String baseUrl = Configuracao.getApiUrl();
            
            // Diagnóstico rápido
            if (apiKey == null || baseUrl == null) {
                return "ERRO: Verifique se o arquivo config.properties tem 'api.key=' e 'api.url='";
            }

            // 2. Preparar o JSON para o Google Gemini
            String promptTratado = prompt.replace("\n", " ").replace("\"", "\\\"");
            String jsonBody = "{"
                    + "\"contents\": [{"
                    + "    \"parts\":[{\"text\": \"" + promptTratado + "\"}]"
                    + "}]"
                    + "}";

            // 3. Montar URL com a chave (Essencial para não dar erro 401)
            String urlFinal = baseUrl + "?key=" + apiKey;

            // 4. Enviar
            System.out.println("... Conectando ao ChefAI ...");
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(urlFinal))
                    .header("Content-Type", "application/json")
                    .POST(BodyPublishers.ofString(jsonBody))
                    .build();

            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                return response.body();
            } else {
                System.out.println(request);
                return "ERRO API (" + response.statusCode() + "): " + response.body();
            }

        } catch (Exception e) {
            return "ERRO DE CONEXÃO: " + e.getMessage();
        }
    }
}