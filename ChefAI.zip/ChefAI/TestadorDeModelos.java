import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;
import java.time.Duration;

public class TestadorDeModelos {
    
    // COLE SUA CHAVE AQUI PARA O TESTE
    private static final String MINHA_CHAVE = "AIzaSyCQWp8GHiHC_ZEsvCW1Bx5e6d7wpxmPFyg"; 

    public static void main(String[] args) {
        System.out.println("=== INICIANDO DIAGNÓSTICO DE MODELOS ===");
        
        // Lista de modelos possíveis para testar
        String[] modelos = {
            "gemini-1.5-flash",          // O padrão rápido
            "gemini-1.5-flash-001",      // A versão específica (às vezes o apelido falha)
            "gemini-1.5-flash-latest",   // A última versão
            "gemini-pro",                // O clássico estável
            "gemini-1.0-pro",             // A versão específica do clássico
            "gemini-2.5-flash"
        };

        HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
        boolean achouUm = false;

        for (String modelo : modelos) {
            System.out.print("Testando modelo: [" + modelo + "] ... ");
            
            try {
                String url = "https://generativelanguage.googleapis.com/v1beta/models/" + modelo + ":generateContent?key=" + MINHA_CHAVE;
                String jsonBody = "{\"contents\": [{\"parts\":[{\"text\": \"Teste\"}]}]}";

                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .POST(BodyPublishers.ofString(jsonBody))
                        .build();

                HttpResponse<String> response = client.send(request, BodyHandlers.ofString());

                if (response.statusCode() == 200) {
                    System.out.println("✅ SUCESSO! (Funcionou)");
                    System.out.println(">>> USE ESTE MODELO NO SEU ARQUIVO: " + modelo);
                    achouUm = true;
                    
                    // Se achou um que funciona, vamos consertar o arquivo automaticamente para você
                    consertarArquivoAutomaticamente(modelo);
                    break; // Para o teste pois já achamos o vencedor
                } else if (response.statusCode() == 429) {
                    System.out.println("⚠️ EXISTE, mas está sem cota (Erro 429).");
                } else if (response.statusCode() == 404) {
                    System.out.println("❌ NÃO ENCONTRADO (Erro 404).");
                } else {
                    System.out.println("❌ ERRO " + response.statusCode());
                }
                
            } catch (Exception e) {
                System.out.println("Erro de conexão: " + e.getMessage());
            }
        }
        
        if (!achouUm) {
            System.out.println("\nNenhum modelo funcionou. Verifique se sua chave API está ativa no Google AI Studio.");
        }
    }

    // Método extra para já salvar o arquivo certo se funcionar
    private static void consertarArquivoAutomaticamente(String modeloCerto) {
        try {
            java.util.Properties props = new java.util.Properties();
            props.setProperty("api.key", MINHA_CHAVE);
            props.setProperty("api.url", "https://generativelanguage.googleapis.com/v1beta/models/" + modeloCerto + ":generateContent");
            
            java.io.FileOutputStream fos = new java.io.FileOutputStream("config.properties");
            props.store(fos, "Configuracao Corrigida Automaticamente");
            fos.close();
            System.out.println("\n✨ O ARQUIVO 'config.properties' FOI ATUALIZADO COM O MODELO " + modeloCerto + " ✨");
            System.out.println("Pode rodar o LLMClient agora!");
        } catch (Exception e) {
            System.out.println("Erro ao salvar arquivo: " + e.getMessage());
        }
    }
}