import java.util.Scanner;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Ferramenta para ler o teclado
        Scanner leitor = new Scanner(System.in);
        
        System.out.println("=== BEM-VINDO AO CHEFAI ===");
        System.out.print("Qual é o seu nome? ");
        String nomeUsuario = leitor.nextLine();
        
        // Cria o usuário com o nome digitado
        Usuario usuario = new Usuario(nomeUsuario);
        
        // Cria o sugestor (o cérebro)
        SugestorReceitas sugestor = new SugestorRapido();
        
        boolean rodando = true;

        while (rodando) {
            System.out.println("\n--------------------------------");
            System.out.println("Olá, " + usuario.getNome() + ". O que deseja fazer?");
            System.out.println("1 - Ver minha despensa");
            System.out.println("2 - Adicionar ingrediente");
            System.out.println("3 - Adicionar restrição alimentar");
            System.out.println("4 - CONSULTAR CHEF (Gerar Receitas)");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            
            String opcao = leitor.nextLine();

            switch (opcao) {
                case "1":
                    System.out.println("\n=== SUA DESPENSA ===");
                    if (usuario.getDespensa().isEmpty()) {
                        System.out.println("(Vazia)");
                    } else {
                        for (Ingrediente i : usuario.getDespensa()) {
                            System.out.println("- " + i);
                        }
                    }
                    if (!usuario.getRestricoes().isEmpty()) {
                        System.out.println("Restrições: " + usuario.getRestricoes());
                    }
                    break;

                case "2":
                    System.out.print("Nome do ingrediente: ");
                    String nomeIng = leitor.nextLine();
                    
                    System.out.print("Quantidade (ex: 200g, 1 un): ");
                    String qtdIng = leitor.nextLine();
                    
                    usuario.adicionarNaDespensa(nomeIng, qtdIng);
                    System.out.println(">> Ingrediente adicionado!");
                    break;

                case "3":
                    System.out.print("Qual a restrição (ex: Sem Glúten, Vegano)? ");
                    String rest = leitor.nextLine();
                    usuario.adicionarRestricao(rest);
                    System.out.println(">> Restrição registrada!");
                    break;

                case "4":
                    if (usuario.getDespensa().isEmpty()) {
                        System.out.println("\nERRO: Sua despensa está vazia! Adicione ingredientes primeiro.");
                    } else {
                        System.out.println("\n... Consultando a Inteligência Artificial ...");
                        
                        List<Receita> receitas = sugestor.gerarSugestoes(usuario);
                        
                        System.out.println("\n======= SUGESTÕES DO CHEF =======");
                        if (receitas.isEmpty()) {
                            System.out.println("O Chef não conseguiu gerar receitas. Tente novamente.");
                        } else {
                            for (Receita r : receitas) {
                                // MUDANÇA AQUI: Passamos a despensa do usuário como parâmetro!
                                System.out.println(r.getDetalhes(usuario.getDespensa()));
                                System.out.println("---------------------------------");
                            }
                        }
                    }
                    break;
                case "0":
                    System.out.println("Saindo... Bom apetite!");
                    rodando = false;
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        }
        
        leitor.close();
    }
}