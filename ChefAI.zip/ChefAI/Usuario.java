import java.util.ArrayList;
import java.util.List;

public class Usuario {
    private String nome;
    private List<Ingrediente> despensa;
    private List<String> restricoes;

    public Usuario(String nome) {
        this.nome = nome;
        this.despensa = new ArrayList<>();
        this.restricoes = new ArrayList<>();
    }

    public void adicionarNaDespensa(String nomeIngrediente, String qtd) {
        this.despensa.add(new Ingrediente(nomeIngrediente, qtd));
    }

    public void adicionarRestricao(String restricao) {
        this.restricoes.add(restricao);
    }

    public List<Ingrediente> getDespensa() {
        return despensa;
    }

    public List<String> getRestricoes() {
        return restricoes;
    }
    
    public String getNome() {
        return this.nome;
    }
}