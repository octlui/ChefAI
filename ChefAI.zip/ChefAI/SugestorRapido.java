/**
 * Especialista em receitas rápidas.
 * Herda toda a inteligência da mãe, só muda a instrução especial.
 */
public class SugestorRapido extends SugestorReceitas {

    @Override
    protected String getInstrucaoEspecial() {
        return "Prioridade TOTAL para velocidade. Sugira apenas receitas que fiquem prontas em menos de 30 minutos. " +
               "Seja prático e direto.";
    }
}